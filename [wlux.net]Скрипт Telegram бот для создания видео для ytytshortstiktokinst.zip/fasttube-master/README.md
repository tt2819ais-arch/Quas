![](https://github.com/user-attachments/assets/e84e0c48-f398-4b1a-9ef4-41118b761dd2)

# 🎵 [FastTube](https://t.me/fasttubesmbot) - telegram bot to help producers promote their work

### ✍️ About 
FastTube - part of services for artists & producers by [SeaMusic](https://github.com/seamusic-official). This is telegram bot for creating videos for yt/ytshorts/tiktok/inst with the ability to upload videos from the bot directly to YouTube without browser. Also, you can manage your profile on any service from our team
