from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from src.keyboards.emoji import *


settings = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="Your channel", url="https://t.me/whyspacy")]
])
